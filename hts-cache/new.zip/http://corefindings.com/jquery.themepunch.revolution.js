<!DOCTYPE HTML>
<html lang="en">

	<!-- START head -->
	<head><link rel="stylesheet" type="text/css" href="http://corefindings.com/wp-content/cache/minify/000000/fc0xDsIwDIXhCxGZTlyBgQGJgTk4JlhKncp2K_X2JC0LQmL9_el5gEtcSW-FEymYR2cENIPSs235MABW8YgenlXHcAIWLHMi26T5WsgaIjMS51hCVk4wzY_SxmKr_pHkzpK7VVr28X_sCGfOL5J0v-5fvkqnSjZVMV5-T4x1rFXe.css" media="all" />

	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="pingback" href="http://corefindings.com/xmlrpc.php" />

				
	
	<!--[if lte IE 8]>
	<script src="http://corefindings.com/wp-content/themes/HighendWP/scripts/html5shiv.js" type="text/javascript"></script>
	<![endif]-->

	<title>Page not found &#8211; Core Findings</title>
<link rel="alternate" type="application/rss+xml" title="Core Findings &raquo; Feed" href="http://corefindings.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Core Findings &raquo; Comments Feed" href="http://corefindings.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/corefindings.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.5.3"}};
			!function(a,b,c){function d(a){var c,d,e,f=b.createElement("canvas"),g=f.getContext&&f.getContext("2d"),h=String.fromCharCode;if(!g||!g.fillText)return!1;switch(g.textBaseline="top",g.font="600 32px Arial",a){case"flag":return g.fillText(h(55356,56806,55356,56826),0,0),f.toDataURL().length>3e3;case"diversity":return g.fillText(h(55356,57221),0,0),c=g.getImageData(16,16,1,1).data,d=c[0]+","+c[1]+","+c[2]+","+c[3],g.fillText(h(55356,57221,55356,57343),0,0),c=g.getImageData(16,16,1,1).data,e=c[0]+","+c[1]+","+c[2]+","+c[3],d!==e;case"simple":return g.fillText(h(55357,56835),0,0),0!==g.getImageData(16,16,1,1).data[0];case"unicode8":return g.fillText(h(55356,57135),0,0),0!==g.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

<link rel='stylesheet' id='ls-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900%7COpen+Sans:300%7CIndie+Flower:regular%7COswald:300,regular,700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />


<link rel='stylesheet' id='tp-open-sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700%2C800&#038;ver=4.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='tp-raleway-css'  href='http://fonts.googleapis.com/css?family=Raleway%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900&#038;ver=4.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='tp-droid-serif-css'  href='http://fonts.googleapis.com/css?family=Droid+Serif%3A400%2C700&#038;ver=4.5.3' type='text/css' media='all' />

<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.largeredbtn{font-family:"Raleway",sans-serif;font-weight:900;font-size:16px;line-height:60px;color:#fff !important;text-decoration:none;padding-left:40px;padding-right:80px;padding-top:22px;padding-bottom:22px;background:rgb(234,91,31); background:-moz-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(234,91,31,1)),color-stop(100%,rgba(227,58,12,1))); background:-webkit-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-o-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:-ms-linear-gradient(top,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); background:linear-gradient(to bottom,rgba(234,91,31,1) 0%,rgba(227,58,12,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#ea5b1f',endColorstr='#e33a0c',GradientType=0 )}.largeredbtn:hover{background:rgb(227,58,12); background:-moz-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(227,58,12,1)),color-stop(100%,rgba(234,91,31,1))); background:-webkit-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-o-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:-ms-linear-gradient(top,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); background:linear-gradient(to bottom,rgba(227,58,12,1) 0%,rgba(234,91,31,1) 100%); filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#e33a0c',endColorstr='#ea5b1f',GradientType=0 )}.fullrounded img{-webkit-border-radius:400px;-moz-border-radius:400px;border-radius:400px}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>



<script type="text/javascript" src="http://corefindings.com/wp-content/cache/minify/000000/lY9LDoMwDAUvBIkqrtFdT2CCFQz5UNuRyu0baNRdJbqznmZsv8Euz4K8d0Mb-kieQdFESt3N3mFHfgSakK0oKDm7iPWMmCS79ScRjlTO1KyMoIUh4kRg2r0rojIkIaWcpPIogkkJQu-ZJruVMVQFaqpymuRnHfPrAvr5weiMEbeS3Gw05yCt8__21zg2vAE.js"></script>
<script type="text/javascript" src="http://corefindings.com/wp-content/cache/minify/000000/DcpLDoAgDAXAG9F4JMWXUFMK9GPi7SWZ5RxkeF34htHMS7jS6Y5weraVsK9EQ8dMra3sPCSDh5bO-gM.js"></script>
<link rel='https://api.w.org/' href='http://corefindings.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://corefindings.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://corefindings.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.5.3" />
		<script type="text/javascript">
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				var ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = 'ed5be392c9';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"http://corefindings.com/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});
		</script>
				<style type="text/css">
		
		::selection { background:#68c2ff; color:#FFF; }
		::-moz-selection { background:#68c2ff; color:#FFF; }

		a:hover, .user-entry a,
		#lang_sel_footer a:hover,
		.widget_calendar tbody a,
		#header-bar a:hover,
		.minimal-skin #main-nav > li a:hover,
		#header-inner.stuck .second-skin #main-nav > li > a:hover,
		.minimal-skin #main-nav li.current-menu-item > a,
		.minimal-skin #main-nav li.sfHover > a, 
		.minimal-skin #main-nav > li.current-menu-ancestor > a,
		#close-fancy-search,
		article.search-entry a.search-thumb:hover,
		.map-info-section .minimize-section:hover,
		.hb-blog-small h3.title a:hover,
		.post-header .post-meta-info a:hover,
		.post-content h2.title a,
		.like-holder:hover i,
		.comments-holder:hover i,
		.share-holder:hover i,
		.comments-holder a:hover,
		.hb-blog-grid .comments-holder:hover, 
		.hb-blog-grid .like-holder:hover,
		.most-liked-list li:hover .like-count,
		.simple-read-more:hover,
		.team-member-box:hover .team-member-name,
		.testimonial-author .testimonial-company:hover,
		.close-modal:hover,
		.hb-tabs-wrapper .nav-tabs li.active a,
		.hb-icon,
		.hb-logout-box small a:hover,
		.hb-gallery-sort li.hb-dd-header:hover strong,
		.filter-tabs li a:hover,
		ul.social-list li a:hover,
		div.pp_default .pp_close:hover,
		#main-wrapper .hb-woo-product.sale .price,
		.woocommerce .star-rating span, .woocommerce-page .star-rating span,
		.woocommerce-page div.product p.price, .hb-focus-color,
		#main-wrapper .hb-main-content .hb-blog-box-categories a:hover { color:#68c2ff; }

		.hb-focus-color, 
		.light-text a:hover, 
		#header-bar.style-1 .top-widget .active,
		#header-bar.style-2 .top-widget .active, 
		.top-widget:hover > a,
		#header-bar.style-2 .top-widget:hover > a,
		.top-widget.social-list a:hover,
		#main-wrapper .hb-dropdown-box a:hover,
		.social-list ul li a:hover,
		.light-menu-dropdown #main-nav ul.sub-menu li a:hover,
		.light-menu-dropdown #main-nav ul.sub-menu li.sfHover > a,
		.light-menu-dropdown #main-nav ul.sub-menu li.current-menu-item > a,
		.light-menu-dropdown #main-nav ul.sub-menu li.current-menu-ancestor > a,
		#fancy-search .ui-autocomplete li a:hover,
		#fancy-search .ui-autocomplete li:hover span.search-title,
		#fancy-search .ui-autocomplete li a,
		.share-holder .hb-dropdown-box ul li a:hover,
		.share-holder .hb-dropdown-box ul li a:hover i,
		.share-holder.active,
		.share-holder.active i,
		.author-box .social-list li a:hover,
		#respond small a:hover,
		.commentmetadata a:hover time,
		.comments-list .reply a,
		#footer.dark-style a:hover,
		.feature-box i.ic-holder-1,
		.feature-box.alternative i.ic-holder-1,
		.portfolio-simple-wrap .standard-gallery-item:hover .portfolio-description h3 a,
		#copyright-wrapper a:hover,
		.hb-effect-1 #main-nav > li > a::before, 
		.hb-effect-1 a::after,
		.third-skin.hb-effect-1 #main-nav > li > a:hover, 
		.third-skin.hb-effect-1 #main-nav > li.current-menu-item > a, 
		.third-skin.hb-effect-1 #main-nav > li.sfHover > a,
		.second-skin.hb-effect-9 #main-nav #nav-search > a:hover,
		.hb-effect-10 #main-nav > li > a:hover, 
		.hb-effect-10 #main-nav > li #nav-search a:hover, 
		.hb-effect-10 #main-nav > li.current-menu-item > a,
		.like-holder:hover,
		.comments-holder:hover,
		.share-holder:hover,
		#main-nav ul.sub-menu li a:hover,
		.hb-side-nav li.menu-item-has-children:hover > a,
		.hb-side-nav li a:hover, .hb-side-nav li.current-menu-item > a, .hb-side-nav li.current-menu-ancestor > a,
		.hb-post-carousel .hb-post-info .hb-post-title:hover,
		.hb-post-carousel .hb-owl-item .hb-owl-read-more:hover span,
		.hb-post-carousel .hb-owl-item .hb-owl-read-more:hover { color: #68c2ff!important; }

		.light-style .feature-box i.ic-holder-1,
		.light-style .feature-box.alternative i.ic-holder-1,
		.light-style .feature-box h4.bold {
			color: #f9f9f9 !important;
		}

		.light-style .feature-box-content p {
			color: #ccc;
		}

		.like-holder.like-active i, .like-holder.like-active { color: #da4c26 !important; }

		.hb-icon-container,
		.feature-box i.ic-holder-1 {
			border-color: #68c2ff;
		}

		.main-navigation.default-skin #main-nav > li > a:hover > span, 
		.main-navigation.default-skin #main-nav > li.current-menu-item > a > span, 
		.main-navigation.default-skin #main-nav > li.sfHover > a > span,
		.simple-read-more,
		.team-member-box.tmb-2:hover .team-member-description,
		.hb-logout-box small a:hover,
		#pre-footer-area,
		span[rel="tooltip"] { border-bottom-color: #68c2ff; }

		.hb-pricing-item:hover,
		.hb-process-steps ul:before,
		.pace .pace-activity,
		.wpb_tabs .nav-tabs li.active a,
		#hb-preloader .spinner, .default-loading-icon:before {
			border-top-color: #68c2ff;
		}

		blockquote.pullquote,
		.author-box,
		#main-wrapper .widget_nav_menu ul.menu li.current-menu-item > a,
		.hb-callout-box h3,
		.pace .pace-activity,
		.hb-non-transparent .hb-side-nav > li > a:hover,
		.hb-non-transparent .hb-side-nav > li.current-menu-item > a, 
		.hb-non-transparent .hb-side-nav > li.current-menu-ancestor > a, 
		.hb-non-transparent .hb-side-nav > li.sfHover > a,
		.hb-tabs-wrapper.tour-style.left-tabs > .nav-tabs > li.active a,
		.logout-dropdown ul li:hover,
		.light-menu-dropdown #main-nav ul.sub-menu li a:hover,.light-menu-dropdown #main-nav ul.sub-menu li.sfHover > a,.light-menu-dropdown #main-nav ul.sub-menu li.current-menu-item > a, .light-menu-dropdown #main-nav ul.sub-menu li.current-menu-ancestor > a, .light-menu-dropdown #main-nav ul.sub-menu li.sfHover > a {
			border-left-color: #68c2ff;
		}

		#main-wrapper .right-sidebar .widget_nav_menu ul.menu li.current-menu-item > a,
		.hb-tabs-wrapper.tour-style.right-tabs > .nav-tabs > li.active a{
			border-right-color: #68c2ff;
		}

		#to-top:hover,
		#contact-button:hover, 
		#contact-button.active-c-button,
		.pagination ul li span, 
		.single .pagination span,
		.single-post-tags a:hover,
		div.overlay,
		.portfolio-simple-wrap .standard-gallery-item:hover .hb-gallery-item-name:before,
		.progress-inner,
		.woocommerce .wc-new-badge,
		#main-wrapper .coupon-code input.button:hover,
		.woocommerce-page #main-wrapper button.button:hover,
		#main-wrapper input.checkout-button,
		.side-nav-bottom-part ul li a:hover,
		#main-wrapper #place_order,
		#mobile-menu.interactive .open-submenu.active,
		#mobile-menu.interactive .open-submenu:hover,
		.widget_product_search input[type=submit] { background-color:#68c2ff; }

		#header-dropdown .close-map:hover,
		#sticky-shop-button:hover,
		#sticky-shop-button span,
		.quote-post-format .quote-post-wrapper a,
		.link-post-format .quote-post-wrapper a,
		.status-post-format .quote-post-wrapper a,
		span.highlight,
		mark,
		.feature-box:hover:not(.standard-icon-box) .hb-small-break,
		.content-box i.box-icon,
		.hb-button, input[type=submit], a.read-more,
		.hb-effect-2 #main-nav > li > a > span::after,
		.hb-effect-3 #main-nav > li > a::before,
		.hb-effect-4 #main-nav > li > a::before,
		.hb-effect-6 #main-nav > li > a::before,
		.hb-effect-7 #main-nav > li > a span::after,
		.hb-effect-8 #main-nav > li > a:hover span::before,
		.hb-effect-9 #main-nav > li > a > span::before,
		.hb-effect-9 #main-nav > li > a > span::after,
		.hb-effect-10 #main-nav > li > a:hover span::before, 
		.hb-effect-10 #main-nav > li.current-menu-item > a span::before, 
		#main-nav > li.sfHover > a span::before, 
		#main-nav > li.current-menu-ancestor > a span::before,
		.pace .pace-progress,
		#main-wrapper .hb-bag-buttons a.checkout-button,
		.hb-owl-slider .owl-prev:hover,
		.hb-owl-slider .owl-next:hover { background: #68c2ff; }

		.filter-tabs li.selected a, #main-wrapper .single_add_to_cart_button:hover {
			background: #68c2ff !important;
		}

		table.focus-header th,
		.second-skin #main-nav > li a:hover,
		.second-skin #main-nav > li.current-menu-item > a,
		.second-skin #main-nav > li.sfHover > a,
		#header-inner.stuck .second-skin #main-nav > li > a:hover,
		.second-skin #main-nav > li.current-menu-item > a,
		.crsl-nav a:hover,
		.feature-box:hover i.ic-holder-1 {
			background: #68c2ff;
			color: #FFF;
		}


		.load-more-posts:hover,
		.dropcap.fancy,
		.tagcloud > a:hover,
		.hb-icon.hb-icon-medium.hb-icon-container:hover {
			background-color: #68c2ff;
			color: #FFF;
		}

		.filter-tabs li.selected a {
			border-color: #68c2ff !important;
		}

		.hb-second-light:hover {background:#FFF!important;color:#68c2ff!important;}

		.hb-effect-11 #main-nav > li > a:hover::before,
		.hb-effect-11 #main-nav > li.sfHover > a::before,
		.hb-effect-11 #main-nav > li.current-menu-item > a::before,
		.hb-effect-11 #main-nav > li.current-menu-ancestor > a::before  {
			color: #68c2ff;
			text-shadow: 7px 0 #68c2ff, -7px 0 #68c2ff;
		}

		#main-wrapper .product-loading-icon {
			background: rgba(104,194,255,0.85);
		}

		.hb-single-next-prev a:hover {
			background: #68c2ff;	
		}

		.hb-more-details:hover, .hb-buy-button:hover {
			color:#FFF;
			background: rgba(104,194,255,0.8);
		}

		.hb-button, input[type=submit]{
			box-shadow: 0 3px 0 0 #3690cd;
		}

		.hb-button.special-icon i,
		.hb-button.special-icon i::after {
			background:#3690cd;
		}

		#main-wrapper a.active-language, #main-wrapper a.active-language:hover {color: #aaa !important; }
		.feature-box:hover:not(.standard-icon-box):not(.alternative) i, #main-wrapper .hb-bag-buttons a:hover, #main-wrapper .hb-dropdown-box .hb-bag-buttons a:hover,
		#main-wrapper .social-icons.dark li a:hover i, #main-wrapper #footer .social-icons.dark li a i, 
		#footer.dark-style ul.social-icons.light li a:hover,
		#main-wrapper .hb-single-next-prev a:hover {color: #FFF !important;}#header-bar a { color:#68c2ff}#header-inner-bg {background-color: #ffffff;}#header-inner.stuck #header-inner-bg { background-color: #ffffff; }#header-inner.nav-type-2 .main-navigation { border-top-color: #e1e1e1; }#header-inner-bg {border-bottom-color: #e1e1e1}#main-nav li#nav-search::before {background:#e1e1e1}#header-inner.nav-type-2 #main-nav > li:first-child > a, #header-inner.nav-type-2 li#nav-search > a { border-left-color: #e1e1e1; }#header-inner.nav-type-2 #main-nav > li > a { border-right-color: #e1e1e1; }#header-inner.stuck #header-inner-bg { border-bottom-color:#f0f0f0 !important; }#header-inner.stuck #main-nav li#nav-search::before {background: #f0f0f0}#main-wrapper #header-inner.stuck #main-nav > li > a, #main-wrapper #header-inner.stuck #header-inner-bg { color:#444444 !important; }#pre-footer-area {background-color: #ececec;}#pre-footer-area {color: #323436;}#footer, body #lang_sel_footer { background-color: #3d4045; }#footer { color: #999999; }#main-wrapper #footer {color: #999999;}#main-wrapper #footer a, body #lang_sel_footer a { color: #ffffff; }#copyright-wrapper {background: #43474d;}#copyright-wrapper, #copyright-text {color: #999999;}#copyright-wrapper a {color: #ffffff;}body {background-color: #ffffff;}#hb-side-section {background-color: #68c2ff;}#main-wrapper, #main-wrapper.hb-stretched-layout, #main-wrapper.hb-boxed-layout {background-color: #ffffff;}#main-wrapper #pre-footer-area:after {border-top-color: #ffffff;}#main-wrapper .hb-main-content, #main-wrapper .hb-sidebar, .hb-testimonial-quote p {color: #666666;}#main-wrapper .hb-main-content a, select { color: #252525 }#main-wrapper .hb-main-content a:hover {color: #68c2ff;}
					.portfolio-single-meta ul, .content-box, #main-wrapper .hb-accordion-pane, .hb-accordion-tab, .hb-box-cont, .hb-tabs-wrapper.tour-style .tab-content, .hb-tabs-wrapper .nav-tabs li a, .hb-callout-box, .hb-teaser-column .teaser-content, .hb-pricing-item, .hb-testimonial:after, .hb-testimonial, .tmb-2 .team-member-description, .recent-comments-content, .recent-comments-content:after, .hb-tweet-list.light li, .hb-tweet-list.light li:after, fieldset,table,.wp-caption-text, .gallery-caption, .author-box, .comments-list .children > li::before, .widget_nav_menu ul.menu, .comments-list li.comment > div.comment-body, .hb-dropdown-box, #contact-panel, .filter-tabs li a, #contact-panel::after, .hb-flexslider-wrapper.bordered-wrapper,.bordered-wrapper, iframe.fw {border-color:#f0f0f0;}

				#main-content .left-sidebar .hb-main-content.col-9, table th, table th, table td, #main-content .hb-sidebar, .comments-list .children, .tmb-2 .team-member-img, .hb-tabs-wrapper .tab-content, div.pp_default .pp_close {border-left-color:#f0f0f0;}

				table td, .hb-blog-small .meta-info, #main-wrapper .widget_nav_menu ul.menu ul li:first-child, #main-wrapper .bottom-meta-section, .comments-list .children > li::after, .tmb-2 .team-member-img, h5.hb-heading span:not(.special-amp):before, h4.hb-heading span:not(.special-amp):before,h4.hb-heading span:not(.special-amp):after,h5.hb-heading span:not(.special-amp):after,h3.hb-heading span:not(.special-amp):before,h3.hb-heading span:not(.special-amp):after,h4.lined-heading span:not(.special-amp):before,h4.lined-heading span:not(.special-amp):after, .hb-fw-separator, .hb-separator-s-1, .hb-separator-extra, .hb-separator-25, .hb-gal-standard-description .hb-small-separator {border-top-color:#f0f0f0;}

				.woocommerce div.product .woocommerce-tabs ul.tabs:before {border-bottom-color:#f0f0f0;}

				.pricing-table-caption, .pricing-table-price, #hb-page-title, .share-holder .hb-dropdown-box ul li, .hb-blog-small .meta-info, .hb_latest_posts_widget article, .most-liked-list li, ul.hb-ul-list.line-list li, ol.line-list li, ul.line-list li, #hb-blog-posts.unboxed-blog-layout article, .hb-tabs-wrapper .nav-tabs, #main-wrapper .wpb_content_element .wpb_tour_tabs_wrapper .wpb_tabs_nav a, .hb-tabs-wrapper .tab-content, .hb-tabs-wrapper.tour-style .nav-tabs li.active a, .hb-box-cont-header, .hb-separator.double-border, .portfolio-single-meta ul.meta-list li {border-bottom-color:#f0f0f0;}

				#main-content .col-9.hb-main-content, #main-content .left-sidebar .hb-sidebar.col-3, .tmb-2 .team-member-img, .hb-tabs-wrapper .tab-content, .hb-tabs-wrapper.tour-style.right-tabs .nav-tabs > li.active a, div.pp_default .pp_nav {border-right-color:#f0f0f0;}

				.pagination ul li a, .pagination ul li span.page-numbers.dots, .single .pagination a, .page-links a, .hb-skill-meter .hb-progress-bar, .hb-counter .count-separator span, .hb-small-break, hr {background-color: #f0f0f0;}

				#main-wrapper .hb-tabs-wrapper:not(.wpb_tabs) ul li:last-child a, .darker-border .hb-separator {border-bottom-color: #f0f0f0 !important;}
				.darker-border .hb-separator {border-top-color: #f0f0f0 !important;}.hb-special-header-style #main-wrapper #header-inner.stuck #main-nav > li > a,
					  .hb-special-header-style #main-wrapper #header-inner.stuck #close-fancy-search,
					  .hb-special-header-style #main-wrapper #header-inner.stuck #fancy-search input[type=text] { color: #68c2ff !important; }.hb-special-header-style #main-wrapper #header-inner.stuck #fancy-search ::-webkit-input-placeholder { color: #68c2ff !important; };
					  .hb-special-header-style #main-wrapper #header-inner.stuck #fancy-search ::-moz-input-placeholder { color: #68c2ff !important; };
					  .hb-special-header-style #main-wrapper #header-inner.stuck #fancy-search ::-ms-input-placeholder { color: #68c2ff !important; }/* === PRESENTATION DEMO - CUSTOM STYLES === */
#logo img,.stuck #logo img{max-height:38px!important}.hb-video-color-mask{opacity:.7}#hb-side-section{color:#FFF!important;text-align:center}#hb-side-section .widget-item>h4:after{display:none}#pre-footer-area{border-bottom:none}.hb-page-title h1,.hb-page-title h2,article.single h1.title,h1,h4.hb-focus-color{text-transform:uppercase}#searchsubmit{height:50px}#footer.dark-style .hb-tweet-list.light li,#footer.dark-style .hb-tweet-list.light li:after{border-color:transparent}h4.semi-bold{font-weight:700;text-transform:uppercase}#footer widget-item h4{margin-bottom:30px}.post-content{box-shadow:none;-webkit-box-shadow:none;border:1px solid #f0f0f0}.related-item p.hb-post-excerpt{margin-top:10px}.post-content h2.title{font-size:16px!important;line-height:24px!important;text-transform:uppercase;font-weight:700}.load-more-posts,.load-more-posts.inactive:hover{box-shadow:none!important}#hb-blog-posts .post-content h2{font-weight:700}#footer.dark-style .hb-tweet-list.light li{background:rgba(0,0,0,.05)!important}#footer.dark-style .hb-tweet-list.light li:after{display:none}.post-content{background:#fafafa}a.read-more,a.read-more:hover{padding:0!important;border:none!important;background-color:transparent!important}.aligncenter .breadcrumbs-wrapper{top:auto;bottom:-50px;width:100%;left:0;right:auto;text-align:center}.hb-caption-layer .hb-button{letter-spacing:2px!important}.esg-entry-media img{width:100%!important}.pagination ul li a:hover{color:#FFF!important}.portfolio-related-fw{background:0 0;border-bottom:none!important;border-top:none!important;padding-top:0!important;padding-bottom:0!important}h4.hb-center-heading{text-transform:uppercase;font-size:14px;line-height:24px}.item-overlay-text h4{text-transform:uppercase;letter-spacing:1px;font-size:13px;line-height:23px}.hb-gal-standard-description h3{font-size:14px!important;line-height:24px!important;letter-spacing:2px!important}.item-overlay-text-wrap .hb-small-separator{display:none}#to-top i{margin-right:1px;font-size:20px!important}.esg-loadmore-wrapper{margin-top:80px}.mobile-menu-close{line-height:57px}.hb-button,a.read-more,input[type=submit]{box-shadow:none!important}
.hb-counter .count-number { font-family: 'source_sans_probold'; }
#main-nav li.megamenu.columns-2.align-megamenu-right > ul { left: auto !important; right: 0px !important; }
.about-slider-arrow-down a { color: #ED6162 !important; }
.droid-serif h5 { font-family: "Droid Serif" !important; }
.hb-testimonial-quote p { font-size: 18px; line-height: 28px; color: rgba(255,255,255,0.4); }
.testimonial-quote-meta { font-size: 14px; color: rgba(255,255,255,0.6); }
.team-member-description .simple-read-more { display: none; }
#main-wrapper .hb-main-content .flex-control-nav li a { color: #FFF !important; }
/* === END PRESENTATION DEMO CUSTOM STYLES === */
		</style>
		<script type="text/javascript">var ajaxurl = "http://corefindings.com/wp-admin/admin-ajax.php"</script><meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://corefindings.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><!--[if IE  8]><link rel="stylesheet" type="text/css" href="http://corefindings.com/wp-content/plugins/js_composer/assets/css/vc-ie8.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.0.9 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
	<!-- Theme Options Font Settings -->
	<style type="text/css">
	body, .team-position, .hb-single-next-prev .text-inside, .hb-dropdown-box.cart-dropdown .buttons a, input[type=text], textarea, input[type=email], input[type=password], input[type=tel], #fancy-search input[type=text], #fancy-search .ui-autocomplete li .search-title, .quote-post-format .quote-post-wrapper blockquote, table th, .hb-button, input[type=submit], a.read-more, blockquote.pullquote, blockquote, .hb-skill-meter .hb-skill-meter-title, .hb-tabs-wrapper .nav-tabs li a, #main-wrapper .coupon-code input.button,#main-wrapper .form-row input.button,#main-wrapper input.checkout-button,#main-wrapper input.hb-update-cart,.woocommerce-page #main-wrapper .shipping-calculator-form-hb button.button, .hb-accordion-pane, .hb-accordion-tab {
				font-family: "Raleway", sans-serif;
				font-size: 14px;
				line-height: 26px;
				letter-spacing: 0px;
				font-weight: 500;
			}a.read-more, input[type=submit], .hb-caption-layer .hb-button, .hb-push-button-text, #pre-footer-area .hb-button, .hb-button, .hb-single-next-prev .text-inside, #main-wrapper .coupon-code input.button,#main-wrapper .form-row input.button,#main-wrapper input.checkout-button,#main-wrapper input.hb-update-cart,.woocommerce-page #main-wrapper .shipping-calculator-form-hb button.button { font-weight: 700; letter-spacing: 1px }#hb-side-menu li a, #main-nav ul.sub-menu li a, #main-nav ul.sub-menu ul li a, #main-nav, #main-nav li a, .light-menu-dropdown #main-nav > li.megamenu > ul.sub-menu > li > a, #main-nav > li.megamenu > ul.sub-menu > li > a {
				font-family: "Raleway", sans-serif;
				font-size: 13px;
				letter-spacing: 1px;
				font-weight: 700;
				text-transform: uppercase;
			}#main-nav ul.sub-menu li a, #hb-side-menu ul.sub-menu li a, #main-nav ul.sub-menu ul li a, ul.sub-menu .widget-item h4, #main-nav > li.megamenu > ul.sub-menu > li > a #main-nav > li.megamenu > ul.sub-menu > li > a, #main-nav > li.megamenu > ul.sub-menu > li > a {
				font-family: "Raleway", sans-serif;
				font-size: 13px;
				letter-spacing: 0px;
				font-weight: 500;
				text-transform: none;
			}h1, article.single h1.title, #hb-page-title .light-text h1, #hb-page-title .dark-text h1 {
				font-family: "Raleway", sans-serif;
				font-size: 26px;
				line-height: 34px;
				letter-spacing: 1px;
				font-weight: 700;
			}h2, #hb-page-title h2, .post-content h2.title {
				font-family: "Raleway", sans-serif;
				font-size: 24px;
				line-height: 32px;
				letter-spacing: 0px;
				font-weight: 500;
			}h3, h3.title-class, .hb-callout-box h3, .hb-gal-standard-description h3 {
				font-family: "Raleway", sans-serif;
				font-size: 20px;
				line-height: 28px;
				letter-spacing: 0px;
				font-weight: 500;
			}h4, .widget-item h4, #respond h3, .content-box h4, .feature-box h4.bold {
				font-family: "Raleway", sans-serif;
				font-size: 16px;
				line-height: 24px;
				letter-spacing: 1px;
				font-weight: 700;
			}h6, h6.special {
				font-family: "Raleway", sans-serif;
				font-size: 14px;
				line-height: 22px;
				letter-spacing: 1px;
				font-weight: 700;
			}h1.modern,h2.modern,h3.modern,h4.modern,h5.modern,h6.modern {
				font-family: "Raleway", sans-serif;
				letter-spacing: 1px;
				font-weight: 900;
				text-transform: uppercase;
			}	</style>

	<title>  Page not found</title>

	</head>
	<!-- END head -->

	
	<!-- START body -->
	<body class="error404  hb-alt-sidebar hb-modern-search highend-prettyphoto hb-stretched-layout wpb-js-composer js-comp-ver-4.8.0.1 vc_responsive" data-fixed-footer="1" itemscope="itemscope" itemtype="http://schema.org/WebPage">

			<div id="hb-preloader">

			<!--<div class="spinner"></div>-->
			<span class="default-loading-icon"></span>
			
		</div>
	
	
	
	<div id="mobile-menu-wrap">
<div class="hb-top-holder"></div><a class="mobile-menu-close"><i class="hb-icon-x"></i></a>
<nav id="mobile-menu" class="clearfix interactive">
<div class="menu-main-menu-container"><ul id="menu-main-menu" class="menu"><li id="menu-item-1466" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1466"><a href="http://corefindings.com/">Home</a></li>
<li id="menu-item-1478" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1478"><a href="http://corefindings.com/our-services/">Our Services</a>
<ul class="sub-menu">
	<li id="menu-item-1465" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1465"><a href="http://corefindings.com/quick-start/">Quick Start</a></li>
	<li id="menu-item-1464" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1464"><a href="http://corefindings.com/salesforce-administration/">Salesforce Administration</a></li>
	<li id="menu-item-1463" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1463"><a href="http://corefindings.com/salesforce-consulting/">Salesforce Consulting</a></li>
</ul>
</li>
<li id="menu-item-1467" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1467"><a href="http://corefindings.com/contact-core-findings/">Contact Core Findings</a></li>
</ul></div></nav>
</div>


	

	<!-- BEGIN #hb-wrap -->
	<div id="hb-wrap">

	<!-- BEGIN #main-wrapper -->
	<div id="main-wrapper" class="hb-stretched-layout hb_boxed_layout_regular with-shadow width-1140 hb-responsive nav-type-1" data-cart-url="" data-cart-count=""  data-search-header=0>

		
						<!-- BEGIN #hb-header -->
				<header id="hb-header" class=" without-top-bar">

										
        <!-- BEGIN #header-inner -->
        <div id="header-inner" class="sticky-nav nav-type-1 hb-ajax-search clearfix" style="height: 80px; line-height: 80px;" data-height="80" data-sticky-height="50" role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">

            <!-- BEGIN #header-inner-bg -->
            <div id="header-inner-bg">
                
                <!-- BEGIN .container or .container-wide -->
                <div class="container">
                    
                    <!-- BEGIN #logo -->
                    <div id="logo" style="height:80px; line-height: 80px;">
                                                <a href="http://corefindings.com" class="image-logo">

                            
                            <span class="hb-dark-logo hb-visible-logo hb-logo-wrap">
                                <img src="http://corefindings.com/wp-content/uploads/2015/09/Temp-logo-transparent.png" width="318" height="72" class="default" alt="Core Findings"/>
                                
                                                            </span>

                                                            <span class = "hb-light-logo hb-logo-wrap">
                                    <img src="http://corefindings.com/wp-content/uploads/2015/09/Temp-logo-transparent.png" width="318" height="72" class="default" alt="Core Findings"/>

                                                                    </span>
                                                    </a>

                                            </div>
                    <!-- END #logo -->

                    
                    
                    
                    
                    <!-- BEGIN .main-navigation -->
                    <nav class="main-navigation minimal-skin hb-effect-7 dark-menu-dropdown clearfix" style="height: 80px; line-height: 80px;" data-height="80" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">

                        
                        <ul id="main-nav" class="sf-menu "><li id="menu-item-1466" class="menu-item menu-item-type-post_type menu-item-object-page no-megamenu"><a href="http://corefindings.com/"><span>Home</span></a></li>
<li id="menu-item-1478" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children no-megamenu"><a href="http://corefindings.com/our-services/"><span>Our Services</span></a>
<ul style="" class="sub-menu ">
	<li id="menu-item-1465" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://corefindings.com/quick-start/"><span>Quick Start</span></a></li>
	<li id="menu-item-1464" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://corefindings.com/salesforce-administration/"><span>Salesforce Administration</span></a></li>
	<li id="menu-item-1463" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="http://corefindings.com/salesforce-consulting/"><span>Salesforce Consulting</span></a></li>
</ul>
</li>
<li id="menu-item-1467" class="menu-item menu-item-type-post_type menu-item-object-page no-megamenu"><a href="http://corefindings.com/contact-core-findings/"><span>Contact Core Findings</span></a></li>
</ul>
                        

                                                <a href="#" id="show-nav-menu"><i class="icon-bars"></i></a>
                        

                        
                    </nav>
                    <!-- END .main-navigation -->
                    
                                                </div>
                        <!-- END .container or .container-wide -->
                                    </div>
            <!-- END #header-inner-bg -->

        </div>
        <!-- END #header-inner -->


				</header>
				<!-- END #hb-header -->

							

<!-- BEGIN #slider-section -->
<div id="slider-section" class="clearfix " style="">
			<canvas id="hb-canvas-effect"></canvas>
	</div>
<!-- END #slider-section -->		
	

	<!-- BEGIN #main-content -->
	<div id="main-content">
	<div class="container">

		<div class="not-found-box aligncenter">

			<div class="not-found-box-inner">
				<h1 class="extra-large">File not Found</h1>
				<h4 class="additional-desc">Sorry, but we couldn't find the content you were looking for.</h4>
				<div class="hb-separator-s-1"></div>
				<a href="http://corefindings.com" class="hb-button">Back to our Home</a>
			</div>

			<i class="hb-moon-construction"></i>
		</div>

	</div>
	<!-- END .container -->

	</div>
	<!-- END #main-content -->


<!-- Back to Top Button -->
<a id="to-top"><i class="icon-angle-up"></i></a>
<!-- END #to-top -->

<!-- BEGIN #contact-panel -->
<aside id="contact-panel">
    <h4 class="hb-focus-color">Contact Us</h4>
    <p>We're currently offline. Send us an email and we'll get back to you.</p>

    <form id="contact-panel-form">
        <p><input type="text" placeholder="Name" name="hb_contact_name" id="hb_contact_name_id" class="required requiredField" tabindex="33"/></p>
        <p><input type="email" placeholder="Email" name="hb_contact_email" id="hb_contact_email_id" class="required requiredField" tabindex="34"/></p>
        <p><input type="text" placeholder="Subject" name="hb_contact_subject" id="hb_contact_subject_id"/></p>
        <p><textarea placeholder="Your message..." name="hb_contact_message" id="hb_contact_message_id" class="required requiredField" tabindex="35"></textarea></p>
        <a href="#" id="hb-submit-contact-panel-form" class="hb-button no-three-d hb-push-button hb-asbestos hb-small-button">
            <span class="hb-push-button-icon">
                <i class="hb-moon-paper-plane"></i>
            </span>
            <span class="hb-push-button-text">Send Message</span>
        </a>
        <input type="hidden" id="success_text" value="Message Sent!"/>
    </form>

</aside>
<!-- END #contact-panel -->

<!-- BEGIN #hb-contact-button -->
<a id="contact-button"><i class="hb-moon-envelop"></i></a>
<!-- END #hb-contact-button -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-67254953-1', 'auto');
  ga('send', 'pageview');

</script>


<!-- BEGIN #footer OPTION light-style -->
<footer id="footer" class="dark-style background-image" >
	
	<!-- BEGIN .container -->
	<div class="container">
		<div class="row footer-row">

	<div class="col-4 widget-column no-separator"><div id="hb_contact_info_widget-2" class="widget-item hb_contact_info_widget"><h4>Contact Information</h4>
		<ul>
				
			<li><i class="hb-moon-office"></i><span>Core Findings</span></li>												<li><i class="icon-envelope-alt"></i><span><a href="mailto:s&#97;&#108;&#101;&#115;&#64;co&#114;&#101;&#102;i&#110;di&#110;&#103;s.&#99;&#111;&#109;">s&#97;&#108;&#101;s&#64;co&#114;efind&#105;&#110;&#103;s.c&#111;&#109;</a></span></li>			<li><i class="hb-moon-earth"></i><span><a href="http://corefindings.com" target="_blank">corefindings.com</a></span></li>					</ul>

		</div><div id="hb_soc_net_widget-3" class="widget-item hb-socials-widget">
		<ul class="social-icons light small clearfix">
                    
		</ul>

		</div></div><div class="col-8 widget-column no-separator"></div><div class="hidden widget-column no-separator"></div><div class="hidden widget-column no-separator"></div>		</div>		
	</div>
	<!-- END .container -->

</footer>
<!-- END #footer -->

<!-- BEGIN #copyright-wrapper -->
<div id="copyright-wrapper" class="simple-copyright  clearfix"> <!-- Simple copyright opcija light style opcija-->

    <!-- BEGIN .container -->
    <div class="container">

        <!-- BEGIN #copyright-text -->
        <div id="copyright-text">
            <p>© 2015 · Core Findings LLC
            
            </p>
        </div>
        <!-- END #copyright-text -->

        
    </div> 
    <!-- END .container -->

</div>
<!-- END #copyright-wrapper -->

</div>
<!-- END #main-wrapper -->

</div>
<!-- END #hb-wrap -->



	<!-- BEGIN #fancy-search -->
	<div id="modern-search-overlay">
		<a href="#" class="hb-modern-search-close"><i class="hb-icon-x"></i></a>

		<div class="table-middle hb-modern-search-content">
			<p>Type and press Enter to search</p>
			
			<form method="get" id="hb-modern-form" action="http://corefindings.com/" novalidate="" autocomplete="off">
				<input type="text" value="" name="s" id="hb-modern-search-input" autocomplete="off">
			</form>
		</div>

	</div>

<!-- BEGIN #hb-modal-overlay -->
<div id="hb-modal-overlay"></div>
<!-- END #hb-modal-overlay -->

<link rel='stylesheet' id='Raleway-css'  href='//fonts.googleapis.com/css?family=Raleway%3A500%2C700%2C900&#038;subset=latin&#038;ver=4.5.3' type='text/css' media='all' />
<script type="text/javascript" src="http://corefindings.com/wp-content/cache/minify/000000/M9RPzs8rSUwu0U3LL8rVNdfPzEvOKU1JLdbPAqLC0tSiSj2QjF5uZh4A.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/corefindings.com\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="http://corefindings.com/wp-content/cache/minify/000000/M9RPzs8rSUwu0U3LL8rVNdfPzEvOKU1JLdbPKtYvTi7KLCgp1jHQ98hMz0jNSwkPgInhlcsqLE0tqtQDcvNzckLy8alJzi_NK0nJL88DAA.js"></script>
<script type='text/javascript' src='//www.google.com/jsapi?ver=3.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var hb_gmap = {"1":{"lat":"48.856614","lng":"2.352222","ibx":"Enter your info here or leave it empty."}};
/* ]]> */
</script>
<script type="text/javascript" src="http://corefindings.com/wp-content/cache/minify/000000/fY_BDoIwEER_SClEP8KjN8-bdoQ1pa27Ldi_F70QEsLxTV5mMq25cT8guMfdqBVOWc1I6dTu5XBM8BgR8gZ27de7QGrz9PioZwc5siZaFMo4ckBa7UCyPyfQFIPyBEsSi8I3I4ejvjj7ZuNeTGFjo2ClmV2PvHKKypljWJPlf_nT1czpTF1Xf_QF.js"></script>
<script type='text/javascript'>
/* <![CDATA[ */
var uiAutocompleteL10n = {"noResults":"No search results.","oneResult":"1 result found. Use up and down arrow keys to navigate.","manyResults":"%d results found. Use up and down arrow keys to navigate."};
/* ]]> */
</script>
<script type="text/javascript" src="http://corefindings.com/wp-content/cache/minify/000000/M9YvzdRPLC3JT87PLchJLUnVy83M0zHQ98hMz0jNSwkP0C9OLsosKCnWzyosTS2q1EsuLS7Jz9Ux0S8v0E3NTUpNAWkAAA.js"></script>
</body>
<!-- END body -->

</html>
<!-- END html -->
<!-- Performance optimized by W3 Total Cache. Learn more: http://www.w3-edge.com/wordpress-plugins/

Minified using disk
Page Caching using disk: enhanced
Database Caching 50/61 queries in 0.012 seconds using disk

 Served from: corefindings.com @ 2016-08-24 02:04:50 by W3 Total Cache -->